endGame// list of all cards
let cards = ['bicycle', 'bicycle', 'leaf', 'leaf', 'cube', 'cube', 'anchor', 'anchor', 'paper-plane-o', 'paper-plane-o', 'bolt', 'bolt', 'bomb', 'bomb', 'diamond', 'diamond'],



    openCard = [],
    totalCard = cards.length / 2,
    match = 0,
    second = 0,
    nowTime,
    wait = 420,
    moves = 0,
    $container = $('.container'),
    $scorePanel = $('.score-panel'),
    $counter = $('.fa-star'),
    $moves = $('.moves'),
    $time = $('.time'),
    $restart = $('.restart'),
    $deck = $('.deck');

// Shuffling function: enables that no two games have the same card arrangement
function shuffle(array) {
    let currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }
    return array;
}

//  To begin the game
function initGame() {

    // Step 1: shuffles the cards and start with no matching cards and zero moves
    let gameCards = shuffle(cards);
    $deck.empty();
    match = 0;
    moves = 0;
    $moves.text('0');

    // Step 2: adding the cards by using for loop
    for (let i = 0; i < gameCards.length; i++) {
        $deck.append($('<li class="card"><i class="fa fa-' + gameCards[i] + '"></i></li>'))
    }
    flipAndCompare();

    // Step 3: restet the timer to begine the game
    clearTimer(nowTime);
    second = 0;
    $time.text(`${second}`)
    startTimer();
}

//Counter to calculate the score based on the number of moves
function movecounter(moves) {
    let stars = 3;
    if (moves > 14 && moves < 16) {
        $counter.eq(3).removeClass('fa-star').addClass('fa-star-o');//Three stars
    } else if (moves >= 16 && moves < 20) {
        $counter.eq(2).removeClass('fa-star').addClass('fa-star-o');//Two stars
        stars=2;
    } else if (moves >= 20) {
        $counter.eq(1).removeClass('fa-star').addClass('fa-star-o');//One stars
        stars = 1;
    }
    return { score: stars };
}

//Window show when the game end.It showes the score , moves and time to complete the game
function endGame(moves, score) {
  $('#result').text(` WELL DONE , your score is : ${score}`);
    $('#timeAndMove').text(`You complete the game in ${second} seconds and ${moves} moves`);
    $('#endGame').modal('toggle');
}

// restart the game by  Clicking on the restart button
$restart.bind('click', function (restart_game) {
    if (restart_game) {
        $counter.removeClass('fa-star-o').addClass('fa-star');
        initGame();
    }
});

// flipping the card and copmare if they are match
let flipAndCompare = function () {

    // flipping the card
    $deck.find('.card').bind('click', function () {
        let $this = $(this);

        if ($this.hasClass('show') || $this.hasClass('match')) { return true; }

        let card = $this.context.innerHTML;
        $this.addClass('open show');
        openCard.push(card);

        // Compares cards if they matched
        if (openCard.length > 1) {
            if (card === openCard[0]) {
                $deck.find('.open').addClass('match');
                setTimeout(function () {
                    $deck.find('open').removeClass('open show');
                }, wait);
                match++;

            } else {
                $deck.find('.open').addClass('notmatch');
                setTimeout(function () {
                    $deck.find('.open').removeClass('open show');
                }, wait / 1.5);
            }

            openCard = [];
            moves++;
            movecounter(moves);
            $moves.html(moves);
        }

        // if all card open(match) the game end
        if (totalCard === match) {
             movecounter(moves);
            let score =  movecounter(moves).score;
            setTimeout(function () {
                endGame(moves, score);
            }, 500);
        }
    });
}

// strat the timer for the game , it should start from 0 second.
function startTimer() {
    nowTime = setInterval(function () {
        $time.text(`${second}`)
        second++;
    }, 1000);
}

// Resets the timer when the game ends or when the user click on restarted button
function clearTimer(time) {
    if (time) {
        clearInterval(time);
    }
}

initGame();
