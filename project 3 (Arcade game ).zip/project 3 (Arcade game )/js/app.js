var Score = 1;

// Enemy class
var Enemy = function() {

  this.sprite = 'images/enemy-bug.png';
  this.x = Math.floor((Math.random() * 504) + -90);

  //  enemies y position
  this.yArray = [45, 127, 210];
  this.y = this.yArray[Math.floor(Math.random() * this.yArray.length)];
  //  enemy speed
  this.veloc = Math.floor((Math.random() * 30) + 10) * Score;
};

// method 1 : Update the enemy's position
Enemy.prototype.update = function(dt) {
  this.x = this.x + (this.veloc * dt);
  if (this.x > 504) {
    this.x = -90;
    this.y = this.yArray[Math.floor(Math.random() * this.yArray.length)];
    this.veloc = Math.floor((Math.random() * 30) + 10) * Score;
  }

  // Check if enemy and player on the same position

  if ((this.x > player.x - 75 && this.x < player.x + 75) && (this.y > player.y - 75 && this.y < player.y + 75)) {

    player.x = 200;
    player.y = 380;

    allEnemies.forEach(function(enemy) {
      enemy.x = Math.floor((Math.random() * 504) + -90);
      enemy.y = enemy.yArray[Math.floor(Math.random() * enemy.yArray.length)];
    });

    Score = 1;
  }
  document.querySelector('.Score span').innerHTML = Score;
};

// method 2 : Render
Enemy.prototype.render = function() {
  ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Player class
var Player = function() {

  this.x = 200;
  this.y = 380;

  this.sprite = 'images/char-boy.png';
};
//method 1 : handleInput
Player.prototype.handleInput = function(keyDirection) {

  switch (keyDirection) {
    case 'up':
      this.y = this.y - 83;
      if(this.y < 0) {
        this.x = 200;
        this.y = 380;
        Score++;
      }
    break;
    case 'down':
      if(this.y < 380) {
        this.y = this.y + 83;
      }
    break;
    case 'left':
      if(this.x > 0) {
        this.x = this.x - 101;
      }
    break;
    case 'right':
      if(this.x < 400) {
        this.x = this.x + 101;
      }
    break;
  }
};
//method 2 : update
Player.prototype.update = function(dt) {

};

// method 3 : Render
Player.prototype.render = function() {
  ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

//  create enemies objects
var allEnemies = [new Enemy(), new Enemy(), new Enemy()];

// create player object
var player = new Player();

// This listens for key presses and sends the keys to handleInput method
document.addEventListener('keyup', function(e) {
  var allowedKeys = {
    37: 'left',
    38: 'up',
    39: 'right',
    40: 'down'
  };

  player.handleInput(allowedKeys[e.keyCode]);
});
