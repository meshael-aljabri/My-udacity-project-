# Udacity Classic Arcade Game

This is the third project for the Front-End Web Developer program  

## Run Game

1. Download  and extract the zipped Folder

2. Navigate to and open index.html in your web browser

3. Play the game

## How to Play:

1. The goal of the player is to reach the water, without colliding into any one of the enemies

2. You can move left, right, up and down by using keyboard arrow keys

3. If you reaches  the top of the game board, you won and not only the score will increase by one but also the difficult of the game will increases which means the enemies will move faster.

4. when you collides with an enemy, the game is reset and you moves back to the starting position and the score resets to 0
